# Import everything from the api module
from mars_weather_api import *

# Optional: Set version
__version__ = '0.1.0'  # Update with your version