# mars_weather_api

This is a wrapper for the NASA InSight API. 

## Installation

```shell
$ python -m pip install mars_weather_api
```